#include <filesystem>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDir>
#include <QFile>
#include <QMessageBox>
#include <QFileInfo>
#include <QListWidgetItem>
#include <QApplication>
#include <QPalette>
#include <QFont>
#include <QDebug>

namespace fs = std::filesystem;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Configuration de l'interface (style, police, etc.)
    QPalette palette;
    palette.setColor(QPalette::Window, QColor(53, 53, 53));
    palette.setColor(QPalette::WindowText, Qt::white);
    palette.setColor(QPalette::Base, QColor(30, 30, 30));
    palette.setColor(QPalette::AlternateBase, QColor(53, 53, 53));
    palette.setColor(QPalette::ToolTipBase, Qt::white);
    palette.setColor(QPalette::ToolTipText, Qt::white);
    palette.setColor(QPalette::Text, Qt::white);
    palette.setColor(QPalette::Button, QColor(53, 53, 53));
    palette.setColor(QPalette::ButtonText, Qt::white);
    palette.setColor(QPalette::BrightText, Qt::red);
    palette.setColor(QPalette::Link, QColor(42, 130, 218));
    palette.setColor(QPalette::Highlight, QColor(42, 130, 218));
    qApp->setPalette(palette);

    QFont font("Segoe UI", 10);
    qApp->setFont(font);

    this->setWindowTitle("Hus-Clean - Nettoyage de fichiers");
    this->resize(800, 600);
    this->setWindowIcon(QIcon(":/husky.ico"));
    ui->centralwidget->setAutoFillBackground(true);

    connect(ui->scanButton, &QPushButton::clicked, this, &MainWindow::scanFiles);
    connect(ui->cleanButton, &QPushButton::clicked, this, &MainWindow::cleanFiles);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Retourne le nom du navigateur à partir d'un chemin
QString MainWindow::getBrowserNameFromPath(const QString& filePath)
{
    QString browserName = "Inconnu";
    for (const BrowserInfo& browser : browsers) {
        if (filePath.contains(browser.pathSuffix)) {
            browserName = browser.name;
            break;
        }
    }
    return browserName;
}

// Détecte le type de navigateur à partir d'un chemin
BrowserInfo::Type MainWindow::detectBrowserType(const QString& browserPath)
{
    for (const BrowserInfo& browser : browsers) {
        if (browserPath.contains(browser.pathSuffix)) {
            return browser.type;
        }
    }
    return BrowserInfo::UNKNOWN;
}

// Vérifie si un navigateur est en cours d'exécution (fichier verrouillé)
bool MainWindow::isBrowserRunning(const QString& browserPath, BrowserInfo::Type type)
{
    QString lockFile;
    switch (type) {
    case BrowserInfo::FIREFOX:
        lockFile = browserPath + "/.parentlock";
        break;
    default: // Chromium-based browsers
        lockFile = browserPath + "/Lockfile";
        break;
    }
    return QFile::exists(lockFile);
}

// Vérifie si un cookie est indésirable (simplifié en une ligne)
bool MainWindow::isUnnecessaryCookie(const QString& cookieFilePath)
{
    return cookieFilePath.contains("Cookies") || cookieFilePath.endsWith(".ldb") || cookieFilePath.endsWith(".log") || cookieFilePath.endsWith("cookies.sqlite");
}

void MainWindow::scanFiles()
{
    isScanning = true;
    ui->fileListWidget->clear();

    // Scanner les dossiers temporaires
    QString tempPath = qgetenv("TEMP");
    if (!tempPath.isEmpty()) {
        scanDirectory(tempPath);
    }

    QString localTempPath = qgetenv("LOCALAPPDATA") + "/Temp";
    if (!localTempPath.isEmpty()) {
        scanDirectory(localTempPath);
    }

    // Scanner les cookies des navigateurs
    scanBrowserCookies();
    isScanning = false;

    // Message de fin (après la fin du scan)
    QMessageBox::information(this, "Scan terminé !", "Scan des fichiers temporaires et des cookies terminé !");
}

void MainWindow::scanDirectory(const QString& dirPath)
{
    QDir dir(dirPath);
    if (!dir.exists()) return;

    // Lister les fichiers du dossier
    QFileInfoList files = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot);
    for (const QFileInfo& file : files) {
        ui->fileListWidget->addItem(file.absoluteFilePath());
        QApplication::processEvents(); // Mise à jour de l'interface
    }
}

void MainWindow::scanBrowserCookies()
{
    QString localAppData = qgetenv("LOCALAPPDATA");
    QString appData = qgetenv("APPDATA");

    for (const BrowserInfo& browser : browsers) {
        QString browserPath;
        if (browser.type == BrowserInfo::FIREFOX) {
            browserPath = appData + "/" + browser.pathSuffix + "/Profiles";
        } else {
            browserPath = localAppData + "/" + browser.pathSuffix + "/User Data/Default";
        }

        QDir browserDir(browserPath);
        if (!browserDir.exists()) continue;

        // Vérifier si le navigateur est en cours d'exécution
        if (isBrowserRunning(browserPath, browser.type)) {
            ui->fileListWidget->addItem("[" + browser.name + "] Fichiers verrouillés (fermez " + browser.name + ")");
            QApplication::processEvents();
            continue;
        }

        // Scanner les fichiers selon le type de navigateur
        if (browser.type == BrowserInfo::FIREFOX) {
            QFileInfoList profiles = browserDir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);
            for (const QFileInfo& profile : profiles) {
                QString cookiesPath = profile.absoluteFilePath() + "/cookies.sqlite";
                if (QFile::exists(cookiesPath)) {
                    ui->fileListWidget->addItem("[" + browser.name + "] " + QFileInfo(cookiesPath).fileName());
                    QApplication::processEvents();
                }
            }
        } else {
            QFileInfoList files = browserDir.entryInfoList({"Cookies", "Cookies-journal", "*.ldb"}, QDir::Files);
            for (const QFileInfo& file : files) {
                if (isUnnecessaryCookie(file.absoluteFilePath())) {
                    ui->fileListWidget->addItem("[" + browser.name + "] " + file.fileName());
                    QApplication::processEvents();
                }
            }
        }
    }
}

void MainWindow::cleanFiles()
{
    if (isScanning) {
        QMessageBox::warning(this, "Erreur", "Le scan n'est pas terminé. Attendez la fin du scan avant de nettoyer.");
        return;
    }

    int ret = QMessageBox::question(this, "Confirmer le nettoyage", "Voulez-vous vraiment nettoyer ces fichiers ?",
                                     QMessageBox::Yes | QMessageBox::No);
    if (ret == QMessageBox::No) {
        return;
    }

    for (int i = 0; i < ui->fileListWidget->count(); ++i) {
        QListWidgetItem* item = ui->fileListWidget->item(i);
        QString itemText = item->text();

        // Ignorer les fichiers verrouillés
        if (itemText.contains("verrouillés")) {
            continue;
        }

        // Extraire le chemin du fichier
        QString fileName = itemText.mid(itemText.indexOf("] ") + 2);
        QString browserName = itemText.mid(1, itemText.indexOf("]") - 1);
        QString browserPath;

        // Reconstruire le chemin complet
        for (const BrowserInfo& browser : browsers) {
            if (browser.name == browserName) {
                if (browser.type == BrowserInfo::FIREFOX) {
                    QString appData = qgetenv("APPDATA");
                    browserPath = appData + "/" + browser.pathSuffix + "/Profiles/";
                    QDir profilesDir(browserPath);
                    if (profilesDir.exists()) {
                        QFileInfoList profiles = profilesDir.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);
                        for (const QFileInfo& profile : profiles) {
                            QString cookiesPath = profile.absoluteFilePath() + "/cookies.sqlite";
                            if (QFileInfo(cookiesPath).fileName() == fileName) {
                                browserPath = cookiesPath;
                                break;
                            }
                        }
                    }
                } else {
                    QString localAppData = qgetenv("LOCALAPPDATA");
                    browserPath = localAppData + "/" + browser.pathSuffix + "/User Data/Default/" + fileName;
                }
                break;
            }
        }

        if (!browserPath.isEmpty()) {
            QFile file(browserPath);
            if (file.exists()) {
                if (file.remove()) {
                    item->setText(itemText + " - Supprimé");
                } else {
                    item->setText(itemText + " - Erreur (fichier protégé)");
                }
            }
        }
        QApplication::processEvents();
    }

    QMessageBox::information(this, "Nettoyage terminé !", "Le nettoyage des fichiers a été effectué !");
}
